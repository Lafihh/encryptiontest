- Java 6 or later is needed (http://java.com/download)

- Just double click on pte.jar file
or
- use command: start javaw -jar pte.jar

macOS note (can be helpful on first run):
Right Click on pte.jar > Open With > Jar Launcher ... > Open

Linux and HDPI displays (manual UI scale):
java -Xmx1g -Dsun.java2d.uiScale=2.0 -jar pte.jar

-----------------------------------------------------

- We would appreciate any feedback from you regarding suggestions for improvement, technical problems reports and....., you are welcome to contact us via email:
See http://www.paranoiaworks.mobi/sse/about.html to get email address.

-----------------------------------------------------

FAQ
===

Issue: The message is decrypted even when I change the algorithm in the app settings. How is that possible?
Answer: You can set an ENCRYPTION algorithm (the decryption algorithm is detected automatically - the information about the used algorithm is part of the app data format).


Issue: The application produces a completely different output (using the same input) whenever I tap the decrypt button. How is that possible?
Answer: Two words for Google: cryptographic salt

